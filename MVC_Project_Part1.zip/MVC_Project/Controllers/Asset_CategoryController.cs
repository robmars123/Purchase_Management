﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MVC_Project.Models;

namespace MVC_Project.Controllers
{
    public class Asset_CategoryController : Controller
    {
        private AccessDBEntities db = new AccessDBEntities();

        
        // GET: Asset_Category
        public ActionResult Index()
        {
            return View(db.Asset_Categories.ToList());
        }

        // GET: Asset_Category/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Asset_Category asset_Category = db.Asset_Categories.Find(id);
            if (asset_Category == null)
            {
                return HttpNotFound();
            }
            return View(asset_Category);
        }

        // GET: Asset_Category/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Asset_Category/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "AssetCategoryID,AssetCategory")] Asset_Category asset_Category)
        {
            if (ModelState.IsValid)
            {
                db.Asset_Categories.Add(asset_Category);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(asset_Category);
        }

        // GET: Asset_Category/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Asset_Category asset_Category = db.Asset_Categories.Find(id);
            if (asset_Category == null)
            {
                return HttpNotFound();
            }
            return View(asset_Category);
        }

        // POST: Asset_Category/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "AssetCategoryID,AssetCategory")] Asset_Category asset_Category)
        {
            if (ModelState.IsValid)
            {
                db.Entry(asset_Category).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(asset_Category);
        }

        // GET: Asset_Category/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Asset_Category asset_Category = db.Asset_Categories.Find(id);
            if (asset_Category == null)
            {
                return HttpNotFound();
            }
            return View(asset_Category);
        }

        // POST: Asset_Category/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Asset_Category asset_Category = db.Asset_Categories.Find(id);
            db.Asset_Categories.Remove(asset_Category);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
